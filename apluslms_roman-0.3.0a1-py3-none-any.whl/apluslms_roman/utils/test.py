from apluslms_roman.utils.path_mapping import load_from_env_test

env = {
  'PREFIX_FOO.BAR': 'true',
  'foo': 'bar',
  'PREFIX_FOO.BAZ': '[1, 2, 3]',
}

if __name__ == '__main__':
    load_from_env_test(env, 'PREFIX_', '.')